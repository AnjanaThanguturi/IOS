import UIKit

var greeting = "Hello, playground"


//func sumAndAvg(_ numbers:Double...)->(sum:Double,avg:Double){
//   var total:Double=0
//   var avg:Double
//
//   for number in numbers {
//       total+=number
//   }
//   avg=total/Double(numbers.count)
//
//   return (total,avg)
//}
//
//let result=sumAndAvg(1,20.5,3,4.9,10)
//
//print("Sum = \(result.sum)")
//print("Average = \(result.avg)")

func mulAndPerAndSum(_ numbers:Double...)->(mul:Double,per:Double,sum:Double){
   var mul:Double = 1
   var total:Double=0
   
   for number in numbers {
       mul*=number
   }
   
    for number in numbers {
        total+=number
    }
    
    let per = total/100.0
   return (mul,per,total)
}
 
let result=mulAndPerAndSum(2,20.5,3,4.9,10)
 
print("Sum = \(result.sum)")
print("Subtraction = \(result.per)")
print("Multiplication = \(result.mul)")
