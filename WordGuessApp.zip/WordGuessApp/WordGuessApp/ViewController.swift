//
//  ViewController.swift
//  WordGuessApp
//
//  Created by Thanguturi,Anjana on 10/11/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var DisplayLabel: UILabel!
        
        
        @IBOutlet weak var HintLabel: UILabel!
        
        
        @IBOutlet weak var letterEntered: UITextField!
        
        
        @IBOutlet weak var CheckButton: UIButton!
        
        
        @IBOutlet weak var statusLabel: UILabel!
        
        
        @IBOutlet weak var PlayAgainButton: UIButton!
        
       var words = [["SWIFT", "Programming Language"],
                 ["DOG", "Animal"],
                 ["CYCLE", "Two wheeler"],
                 ["MACBOOK", "Apple device"]]
        
        var count = 0;
        var word = ""
        var lettersGuessed = ""
        
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
            //Check button should be disabled.
            CheckButton.isEnabled = false;
            //Get the first word from the array
            word = words[count][0]
            
            DisplayLabel.text = ""
            
            //Populate the display label with the underscores. The # of underscores is equal to the # of characters in the word.
            
            
            //Get the first hint from the array
            HintLabel.text = "Hint: "+words[count][1]
            
            //Clear the status label intially.
            statusLabel.text = ""
        }

        @IBAction func CheckButtonClicked(_ sender: Any) {
            //Get the text from the text field.
            //Replace the guessed letter if the letter is part of the word.
            //Assigning the word to displaylabel after a guess
            //If the word is guessed correctly, we are enabling play again button and disabling the check button.
        }
        
        
        @IBAction func PlayAgainButtonClicked(_ sender: UIButton) {
            
        }
        
        @IBAction func enterLabelChanged(_ sender: UITextField) {
            
            
        }


}

