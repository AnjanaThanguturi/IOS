import UIKit

var greeting = "Hello, playground"
print("Hello World!!!")
print(greeting)
print("Hi", 10, 10.5)
print("Hello World!! " + greeting)
print("Hellow World!! \(greeting)")

var age = 12
print("My age is \(age)") //String Interolation

//print("My age is "+age) concatenation of different datatypes is not allowed.

print("You are \(age) years old and in another \(age) years, you will be \(age * 2)")

print("""
Hello
World!
""")  //<pre></pre>

print ("Hello All,\rWelcome to Swift programming") // \r carriage return - it moves to new line

let  welcomeMessage : String = "Hello!"
print(welcomeMessage , "All")
//welcomeMessage = "Good Bye!!!!" cannot change constants

var name : String = "John"
print(name,2,"Smith")
name = "Bob"
print(name)


print("Welcome to Swift Programming")
print("Fall 2021")
print("*************")
print("Welcome to Swift Programming" , terminator : "$" )
print("Fall 2021")

print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is")
print(1,2,3,4,5,6, separator: "-")


// Variables
var mobileBrand = "Samsung"
mobileBrand = "Apple"
print(mobileBrand)

let pi = 3.14
print(pi)

var age1 : Int = 23
age1 = age1 * 2
print(age1)

var aweMessage = "This is Superb!"
print(aweMessage)
print("aweMessage")

var course1 = "iOS"
var course2 = "Java"
print(course1,course2)
print(course1,"-",course2)

print(5,10,15, terminator: " ")
print(5.5,20.5, separator: "&")


//Tuples - Key, Value pair

var httpError  = (errorCode : 404  , errorMessage : "Page Not Found")
print(httpError)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage )

//using indexes
var name1 = ("John","Smith")
var fName = name1.0
var lName = name1.1
print(fName , terminator : ",")
print(lName)


var origin = (x : 0 , y : 0)
var point = origin
print(point)

// assigning tuple to another tuple using indexes
let city = (name : "Maryville" , population : 11000)
let ( cityName ,cityPopulation ) = (city.0 , city.1)
print(cityName)
print(cityPopulation)
print(type(of: city))

//to print the type of tuple
let groceries = ("bread","onions")
print(groceries.0)
print(groceries.1)
print(type(of: groceries))

//assigning tuple to another tuple by reversing
var fname = "Joe"
var lname = "Root"
(fname , lname) = (lname , fname)
print("First Name is \(fname) and Last Name is \(lname)")

//
var cricketKit = ("handGloves" ,"helmet",("bat","ball"))
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)
