//
//  ViewController.swift
//  DiscountApp
//
//  Created by Thanguturi,Anjana on 9/13/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var amountOutlet: UITextField!
    
    
    @IBOutlet weak var discountOutlet: UITextField!
    
    
    @IBOutlet weak var resultLabelOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func calcDiscount(_ sender: UIButton) {
        var amount = Double(amountOutlet.text!)
        var discountRate = Double(discountOutlet.text!)
        var discount = amount! - (amount!*discountRate!/100)
        resultLabelOutlet.text = "Price after discount is $\(discount)"
    }
    
}

