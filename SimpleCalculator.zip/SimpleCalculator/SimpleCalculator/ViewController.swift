//
//  ViewController.swift
//  SimpleCalculator
//
//  Created by Thanguturi,Anjana on 9/1/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var displayLabel: UILabel!
    var operand1:Double = -1.1
    var operand2:Double = -1.1
    var calcOperator:Character = " "
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func button7Clicked(_ sender: UIButton) {
        displayLabel.text = displayLabel.text! + "7"
        if(operand1 == -1.1){
            operand1 = 7
        }else{
            operand2 = 7
        }
    }
    
    @IBAction func button5Clicked(_ sender: UIButton) {
        displayLabel.text = displayLabel.text! + "5"
        if(operand2 == -1.1){
            operand2 = 5
        }else{
            operand1 = 5
        }
    }
    
    @IBAction func buttonPlusClicked(_ sender: UIButton) {
        displayLabel.text = displayLabel.text! + "+"
        //As the user clicks on plus symbol we need to assign the calcOperator to plus
        if(calcOperator == " "){
            calcOperator = "+"
        }
    }
    
    @IBAction func buttonEqualsClicked(_ sender: UIButton) {
        //displayLabel.text = displayLabel.text! + "="
        if(calcOperator == " "){
            if(operand1 == -1.1 && operand2 == -1.1){
                displayLabel.text = "\(0)"
            }
        }
        if(calcOperator == "+"){
                displayLabel.text = "\(operand1 + operand2)"
        }
        
    }
    
    
    @IBAction func clearClicked(_ sender: UIButton) {
        displayLabel.text = ""
    }
    
}

