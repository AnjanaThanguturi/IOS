//
//  ViewController.swift
//  CourseDisplayApp
//
//  Created by Thanguturi,Anjana on 9/29/22.
//

import UIKit

class ViewController: UIViewController {

    
    
    @IBOutlet weak var displayImageOutlet: UIImageView!
    
    
    @IBOutlet weak var crsNumOutlet: UILabel!
    
    
    @IBOutlet weak var crsTitleOutlet: UILabel!
    
    
    @IBOutlet weak var semOfferedOutlet: UILabel!
    
    
    @IBOutlet weak var previousButtonOutlet: UIButton!
    
    
    @IBOutlet weak var nextButtonOutlet: UIButton!
    
    
    let courses = [["img01","44555","Network Security","Fall 2022"],
    ["img02","44643","Mobile Edge Computing","Spring 2023"],
    ["img03","44656","Data Streaming","Summer 2023"]]
    
    // 1. Open - first course details, previous disable
    // 2. On click Next - next course details, previous enable
    // 3. End of array - next disable, previous enable
    // 4. On click previous - previous code should be diaplayed
    
    var imageNum = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // Display the first course details (0th index) details.
//        displayImageOutlet.image = UIImage(named: courses[0][0])
//        crsNumOutlet.text = courses[0][1]
//        crsTitleOutlet.text = courses[0][2]
//        semOfferedOutlet.text = courses[0][3]
        updateDetails(0)
        
        //Previous button is disabled
        previousButtonOutlet.isEnabled = false
    }

    
    @IBAction func onClickNext(_ sender: UIButton) {
        // The details of the next course should be displayed
        imageNum += 1
//        displayImageOutlet.image = UIImage(named: courses[imageNum][0])
//        crsNumOutlet.text = courses[imageNum][1]
//        crsTitleOutlet.text = courses[imageNum][2]
//        semOfferedOutlet.text = courses[imageNum][3]
        
        updateDetails(imageNum)
        // previous should be enabled
        previousButtonOutlet.isEnabled = true
        
        //Once reach of end of array, next button should be disable
        if(imageNum == courses.count-1){
            nextButtonOutlet.isEnabled = false
        }
    }
    
    
    @IBAction func onClickPrevious(_ sender: UIButton) {
        // The details of the previous course should be displayed
        imageNum -= 1
//        displayImageOutlet.image = UIImage(named: courses[imageNum][0])
//        crsNumOutlet.text = courses[imageNum][1]
//        crsTitleOutlet.text = courses[imageNum][2]
//        semOfferedOutlet.text = courses[imageNum][3]
        updateDetails(imageNum)
        
        //Enable next button
        nextButtonOutlet.isEnabled = true
        
        // once we are at the begining of array, the previous should be disabled
        if(imageNum == 0){
            previousButtonOutlet.isEnabled = false
        }
    }
    
    func updateDetails(_ imageNum:Int){
        displayImageOutlet.image = UIImage(named: courses[imageNum][0])
        crsNumOutlet.text = courses[imageNum][1]
        crsTitleOutlet.text = courses[imageNum][2]
        semOfferedOutlet.text = courses[imageNum][3]
    }
}

