//
//  ViewController.swift
//  Display
//
//  Created by Thanguturi,Anjana on 9/8/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var enterName: UITextField!
    
    @IBOutlet weak var output: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submit(_ sender: UIButton) {
        var name = enterName.text!
        if(name.count>=4){
            //var c = name[name.startIndex..<name.index(name.startIndex,offsetBy:4)]
            var c = name.prefix(4)
            output.text = "\(c)"
        }
        
    }
    
    
}

